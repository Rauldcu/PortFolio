﻿function posicionate(elemento) {
    document.getElementById(elemento).focus();
    document.getElementById(elemento).style.color = '#0000FF';
    document.getElementById(elemento).style.fontWeight = 'bold';

}